This is a derivative of Jose Fernandez's active_scaffold_acts_as_list plug-in.

It has been modified to work with rails-2.1 

